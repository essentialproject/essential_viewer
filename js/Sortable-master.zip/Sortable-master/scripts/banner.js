import { version } from '../package.json';

export default `/**!
 * Sortable ${ version }
 * @author	RubaXa   <trash@rubaxa.org>
 * @author	owenm    <owen23355@gmail.com>
 * @license MIT
 */`;
